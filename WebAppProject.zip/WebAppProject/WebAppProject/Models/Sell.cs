﻿namespace WebAppProject.Models
{
    /*
     * CLASSE QUE SERÁ A "VENDA" 
     */
    public class Sell
    {
    }
}