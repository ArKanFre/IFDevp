﻿namespace WebAppProject.ViewModels
{
    public class RoleViewModels
    {
        public string RoleId { get; set; }

        public string RoleName { get; set; }

    }
}